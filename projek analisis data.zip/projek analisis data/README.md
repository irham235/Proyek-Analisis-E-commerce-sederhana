# E-commerce Dashboard ✨

## Setup environment
```
python=3.12.0
pip install numpy pandas scipy matplotlib seaborn jupyter streamlit babel
```

## Run steamlit app
```
streamlit run dashboard.py
```

